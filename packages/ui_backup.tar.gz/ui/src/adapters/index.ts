export { BlockRegistryAdapter } from './BlockRegistryAdapter.js';
